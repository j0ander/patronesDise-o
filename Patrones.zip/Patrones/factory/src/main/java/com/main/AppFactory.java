package com.main;

import com.implementaciones.FactoryConcret;
import com.implementaciones.Tipos;

public class AppFactory {
    public static void main(String[] args) {
        FactoryConcret prb = new FactoryConcret();
      //  prb.createFactory(Tipos.Cuadros);
    }
}
