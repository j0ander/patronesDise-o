package implementaciones;


public class ProductoFresco extends Producto {
    private String fechaEnvasado;

    public ProductoFresco(String fechaCaducidad, String numeroLote, String paisOrigen, String fechaEnvasado) {
        super(fechaCaducidad, numeroLote, paisOrigen);
        this.fechaEnvasado = fechaEnvasado;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Producto Fresco:");
        mostrarDatosBase();
        System.out.println("  Fecha envasado: " + fechaEnvasado);
    }
}

