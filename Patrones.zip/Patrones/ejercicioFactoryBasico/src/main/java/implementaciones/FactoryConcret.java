package implementaciones;

import interfaces.IFactory;
import interfaces.IProducto;
import main.TipoProducto;

public class FactoryConcret implements IFactory<IProducto> {

    @Override
    public IProducto crearFactory(TipoProducto tipo) {

        switch (tipo) {
            case FRESCO:
                return new ProductoFresco("2025-12-01", "L001", "Ecuador", "2025-11-01");

            case REFRIGERADO:
                return new ProductoRefrigerado("2025-12-10", "L002", "Chile",
                        "ABC123", "2025-11-02", 4.0);

            case CONGELADO_AIRE:
                return new ProductoCongeladoAire("2026-01-10", "L003", "Argentina",
                        "2025-11-03", -20.0, 78, 21, 0.03, 0.97);

            case CONGELADO_AGUA:
                return new ProductoCongeladoAgua("2026-01-12", "L004", "Perú",
                        "2025-11-04", -18.0, 3.5);

            case CONGELADO_NITROGENO:
                return new ProductoCongeladoNitrogeno("2026-02-01", "L005", "Colombia",
                        "2025-11-05", -25.0, "Inmersión", 45);

            default:
                throw new IllegalArgumentException("Tipo no reconocido");
        }

    }
}

