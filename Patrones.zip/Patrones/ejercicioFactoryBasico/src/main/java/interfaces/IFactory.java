package interfaces;

import main.TipoProducto;

public interface IFactory<T extends IProducto> {
    T crearFactory(TipoProducto tipo);
}
