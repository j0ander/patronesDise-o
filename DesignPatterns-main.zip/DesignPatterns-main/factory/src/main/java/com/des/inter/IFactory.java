package com.des.inter;

public interface IFactory {
     <T> T createFactory(String name);
    void init(String pkgName);
}
