package com.app;

import com.impl.ProductoCompuesto;
import com.impl.ProductoPeso;
import com.impl.ProductoUnitario;
import com.model.Pedido;

public class AppComponente {
    public static void main(String[] args) {
        ProductoPeso ps= new ProductoPeso(1.7,3.45,"JAMON","CONGELADOS");
        ProductoPeso ps1= new ProductoPeso(1.7,3.45,"JAMON","CONGELADOS");
        ProductoPeso ps2= new ProductoPeso(1.7,3.45,"JAMON","CONGELADOS");
        ProductoPeso ps3= new ProductoPeso(1.7,3.45,"JAMON","CONGELADOS");

        ProductoUnitario pu = new ProductoUnitario(3, 2.75,"Cola", "GASEOSAS");
        ProductoUnitario pu1 = new ProductoUnitario(2, 2.75,"Arroz", "GASEOSAS");
        ProductoUnitario pu2 = new ProductoUnitario(1, 2.75,"Aceite", "GASEOSAS");
        ProductoUnitario pu3 = new ProductoUnitario(4, 2.75,"Fideos", "GASEOSAS");

        ProductoCompuesto pc = new ProductoCompuesto();
        pc.addProducto(pu3);
        pc.addProducto(ps2);
        pc.addProducto(pu1);

        System.out.println(pc.getImporteTotal());

        Pedido pedido = new Pedido("SDJFH");
        pedido.addProducto(pu);
        pedido.addProducto(ps1);
        pedido.addProducto(ps);
        pedido.addProducto(ps2);
        pedido.addProducto(ps3);

        System.out.println(pedido.getImporteTotal());
        pedido.addProducto(pc);

        System.out.println(pedido.getImporteTotal());
    }
}
