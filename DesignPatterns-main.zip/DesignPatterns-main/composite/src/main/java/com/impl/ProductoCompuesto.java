package com.impl;

import com.inter.IPrecio;

import java.util.ArrayList;

public class ProductoCompuesto implements IPrecio {
    private ArrayList<IPrecio> productos;


    public ProductoCompuesto() {
       this.productos = new ArrayList<>();
    }

    public void addProducto(IPrecio p){
        productos.add(p);
    }

    public void removeProducto(IPrecio p){
        productos.remove(p);
    }

    @Override
    public double getImporteTotal() {
        double tot = 0;
        for(var it : productos){
            tot += it.getImporteTotal();
        }
        return tot;
    }
}
