package com.impl;

import com.inter.IPrecio;

public class ProductoUnitario implements IPrecio {

    private int cantidad;
    private double precio;
    private String nombre;
    private String categoria;

    public ProductoUnitario(int cantidad, double precio, String nombre, String categoria) {
        this.cantidad = cantidad;
        this.precio = precio;
        this.nombre = nombre;
        this.categoria = categoria;
    }

    @Override
    public double getImporteTotal() {

        return precio * cantidad;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCategoria() {
        return categoria;
    }


}
