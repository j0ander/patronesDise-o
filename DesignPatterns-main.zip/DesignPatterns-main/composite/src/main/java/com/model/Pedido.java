package com.model;

import com.impl.ProductoCompuesto;
import com.impl.ProductoPeso;
import com.impl.ProductoUnitario;
import com.inter.IPrecio;

public class Pedido extends ProductoCompuesto {
    private String nombre;

    public Pedido(String nombre) {
        this.nombre = nombre;
    }

    public void addProducto(IPrecio p) {
        super.addProducto(p);
    }
    public void removeProducto(IPrecio p) {
        super.removeProducto(p);
    }
    public void establecerCantidad(IPrecio p) {
        if(p instanceof ProductoUnitario) {
            ProductoUnitario prod = (ProductoUnitario) p;

        }
    }

    public void establecerPeso(IPrecio p) {
        if(p instanceof ProductoPeso) {
            ProductoPeso prod = (ProductoPeso) p;
        }
    }
}
