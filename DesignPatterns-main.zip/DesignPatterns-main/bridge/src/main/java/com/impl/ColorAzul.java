package com.impl;

import com.inter.Color;

public class ColorAzul implements Color {
    @Override
    public void pintar(int borde) {
        System.out.println("Se pinta de color Azul, con borde de: " + borde);
    }

    @Override
    public void probar() {

    }
}
