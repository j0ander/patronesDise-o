package com.impl;

import com.anotaciones.Figuras;
import com.inter.Color;
import com.inter.Figura;
@Figuras(name = "cuadrado")

public class Cuadrado extends Figura {
    public Cuadrado() {
        super(null);
    }

    public Cuadrado(Color color) {
        super(color);
    }
    @Override
    public void dibujarFigura(int borde) {
        System.out.println("se esta creando un cuadrado");
        getColor().pintar(borde);
    }

    @Override
    public void modificarBorde(int borde, int incremento) {
        System.out.println("el borde de la figura fue modificada de: " + borde + ", a: " +incremento);
        borde *= incremento;
        dibujarFigura(borde);
    }
    public void setColor(Color color) {
        super.setColor(color);
    }
}
