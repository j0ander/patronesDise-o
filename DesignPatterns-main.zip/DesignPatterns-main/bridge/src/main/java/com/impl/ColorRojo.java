package com.impl;

import com.inter.Color;

public class ColorRojo implements Color {
    @Override
    public void pintar(int borde) {
        System.out.println("Se pinta de color Rojo, con borde de: " + borde);
    }

    @Override
    public void probar() {

    }
}
