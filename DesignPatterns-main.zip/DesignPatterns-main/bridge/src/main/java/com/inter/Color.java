package com.inter;

public interface Color {
    void pintar(int borde);
    void probar();

}
