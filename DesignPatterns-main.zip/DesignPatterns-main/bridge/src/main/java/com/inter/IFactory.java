package com.inter;

public interface IFactory {
    <T> T createFactory(String name);
    void init(String pkgName);
}
