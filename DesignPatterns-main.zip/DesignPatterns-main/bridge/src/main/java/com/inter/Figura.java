package com.inter;

public  abstract class  Figura {

    private Color color;

    public Figura(Color color) {
        this.color = color;
    }

    public abstract void dibujarFigura(int borde);
    public abstract void modificarBorde(int borde, int incremento);

    public Color getColor() {
        return color;
    }
    public void setColor(Color color) {
        this.color = color;
    }


}
