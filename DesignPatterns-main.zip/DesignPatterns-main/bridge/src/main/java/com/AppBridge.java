package com;

import com.factory.FactoryImpl;
import com.impl.*;
import com.inter.IFactory;


public class AppBridge {
    public static void main(String[] args) {
        IFactory fact = new FactoryImpl();
        fact.init("com");
        Triangulo trg = fact.createFactory("triangulo");
        trg.setColor(new ColorAzul());
        trg.dibujarFigura(10);
        Cuadrado cd = fact.createFactory("cuadrado");
        cd.setColor(new ColorRojo());
        cd.dibujarFigura(10);
        Circulo cir = fact.createFactory("circulo");
        cir.setColor(new ColorRojo());
        cir.dibujarFigura(10);
        Pentagono pt = fact.createFactory("pentagono");
        pt.setColor(new ColorRojo());
        cir.dibujarFigura(10);

    }
}
