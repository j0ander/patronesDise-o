package com.factory;


import com.anotaciones.Figuras;
import com.inter.IFactory;
import com.google.common.reflect.ClassPath;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;

public class FactoryImpl implements IFactory {

    private Map<String, Class> comp = new HashMap<>();

    @Override
    public void init(String pkgName) {
        System.out.println("inicializando buscando");
        try {
            ClassPath classPath = ClassPath.from(FactoryImpl.class.getClassLoader());
            var clases = classPath.getTopLevelClassesRecursive(pkgName);

            for (var it : clases) {
                var miComp = it.load().getAnnotation(Figuras.class);
                if (miComp != null) {
                    comp.put(miComp.name(), it.load());
                    System.out.println("Registrado componente: " + miComp.name());
                }
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public <T> T createFactory(String name) {
        var value = comp.get(name);
        if(value == null){
            throw new RuntimeException("Componente : " + name + " no encontrado");
        }
        try{
            var cto = value.getConstructor();
            Object obj = cto.newInstance();
            return (T) obj;
        }catch(Exception e){
            throw new RuntimeException(e);
        }
    }

}
