package com.main;

import com.fabrica.EmpleadoFabrica;
import com.inter.IEmpleado;

import java.util.Random;
//HACER EL FACTORY GENERICO

public class AppFlayweight {
    private static String[] empleadoTipo = {"Desarrollador", "Tester"};
    private static String[] habilidades = {"java", ".Net", "C#", "Python", "C++"};

    public static void main(String[] args) {
        for (int i = 0; i < 15; i++) {
            IEmpleado e = EmpleadoFabrica.getEmpleado(getRandEmp());
            e.habilidadAsignada(getRandEmp());
            e.tarea();
        }
    }

    public static String getRandEmp() {
        Random r = new Random();
        int rand = r.nextInt(empleadoTipo.length);
        return empleadoTipo[rand];
    }

    public static String getRandSkill() {
        Random r = new Random();
        int rand = r.nextInt(habilidades.length);
        return habilidades[rand];
    }
}

