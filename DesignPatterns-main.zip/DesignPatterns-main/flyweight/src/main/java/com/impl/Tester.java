package com.impl;

import com.inter.IEmpleado;

public class Tester implements IEmpleado {
    private final String JOB;
    private String skill;

    public Tester() {
        this.JOB = "Probar software desarrollador";
    }
    @Override
    public void habilidadAsignada(String skill) {
        this.skill = skill;
    }

    @Override
    public void tarea() {
        System.out.println("Tester con habilidad de: " + this.skill +" realiza: " + this.JOB);
    }
}
