package com.impl;

import com.inter.IEmpleado;

public class Desarrollador implements IEmpleado {
    private final String JOB;
    private String skill;

    public Desarrollador() {
        this.JOB = "Desarrollador de software";
    }
    @Override
    public void habilidadAsignada(String skill) {
        this.skill = skill;
    }

    @Override
    public void tarea() {
        System.out.println("Desarrollador con habilidad: " + this.skill +" cuyo trabajo es: " + this.JOB);
    }
}
