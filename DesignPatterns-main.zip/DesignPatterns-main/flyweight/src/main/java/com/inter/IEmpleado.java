package com.inter;

public interface IEmpleado {

    void habilidadAsignada(String skill);
    void tarea();
}
