package com.progravanzada.terrein;

import android.opengl.GLES20;
import java.nio.*;

public class TerrainMesh {

    private final FloatBuffer vertexBuffer;
    private final ShortBuffer lineIndexBuffer;
    private final int lineCount;

    public TerrainMesh(HeightMap map) {

        int size = map.getSize();
        float[][] h = map.getData();

        // ====== VÉRTICES ======
        float[] vertices = new float[size * size * 3];
        int v = 0;

        for (int z = 0; z < size; z++) {
            for (int x = 0; x < size; x++) {
                vertices[v++] = x * 0.15f;
                vertices[v++] = h[z][x] * 2.5f;
                vertices[v++] = z * 0.15f;
            }
        }

        // ====== ÍNDICES DE LÍNEAS ======
        // Cada cuadrado genera 4 líneas
        short[] lines = new short[(size - 1) * (size - 1) * 8];
        int i = 0;

        for (int z = 0; z < size - 1; z++) {
            for (int x = 0; x < size - 1; x++) {

                short p0 = (short) (z * size + x);
                short p1 = (short) (p0 + 1);
                short p2 = (short) ((z + 1) * size + x);
                short p3 = (short) (p2 + 1);

                // líneas del cuadrado
                lines[i++] = p0; lines[i++] = p1;
                lines[i++] = p1; lines[i++] = p3;
                lines[i++] = p3; lines[i++] = p2;
                lines[i++] = p2; lines[i++] = p0;
            }
        }

        lineCount = lines.length;

        vertexBuffer = ByteBuffer.allocateDirect(vertices.length * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
                .put(vertices);
        vertexBuffer.position(0);

        lineIndexBuffer = ByteBuffer.allocateDirect(lines.length * 2)
                .order(ByteOrder.nativeOrder())
                .asShortBuffer()
                .put(lines);
        lineIndexBuffer.position(0);
    }

    public void draw(int posHandle) {

        GLES20.glEnableVertexAttribArray(posHandle);
        GLES20.glVertexAttribPointer(
                posHandle, 3,
                GLES20.GL_FLOAT, false, 0, vertexBuffer
        );

        GLES20.glLineWidth(1.5f);

        GLES20.glDrawElements(
                GLES20.GL_LINES,
                lineCount,
                GLES20.GL_UNSIGNED_SHORT,
                lineIndexBuffer
        );

        GLES20.glDisableVertexAttribArray(posHandle);
    }
}
