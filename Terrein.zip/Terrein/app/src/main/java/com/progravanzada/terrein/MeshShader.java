package com.progravanzada.terrein;


public class MeshShader {

    public static final String VERTEX =
            "uniform mat4 uMVP;" +
                    "attribute vec3 aPos;" +
                    "void main(){" +
                    "  gl_Position = uMVP * vec4(aPos,1.0);" +
                    "}";

    public static final String FRAGMENT =
            "precision mediump float;" +
                    "void main(){" +
                    "  gl_FragColor = vec4(0.1,0.1,0.1,1.0);" +
                    "}";
}
