package com.progravanzada.terrein;

import java.util.Random;

public class MidpointDisplacement {

    private final Random random = new Random();

    public HeightMap generate(int size, float roughness) {

        HeightMap map = new HeightMap(size);

        map.set(0, 0, random.nextFloat());
        map.set(size - 1, 0, random.nextFloat());
        map.set(0, size - 1, random.nextFloat());
        map.set(size - 1, size - 1, random.nextFloat());

        divide(map, 0, 0, size - 1, size - 1, roughness);
        return map;
    }

    private void divide(HeightMap map,
                        int x1, int z1,
                        int x2, int z2,
                        float roughness) {

        int size = x2 - x1;
        if (size < 2) return;

        int half = size / 2;
        int mx = x1 + half;
        int mz = z1 + half;

        float avg = (
                map.get(x1, z1) +
                        map.get(x2, z1) +
                        map.get(x1, z2) +
                        map.get(x2, z2)
        ) / 4f;

        map.set(mx, mz, avg + offset(roughness));

        map.set(mx, z1, (map.get(x1, z1) + map.get(x2, z1)) / 2 + offset(roughness));
        map.set(mx, z2, (map.get(x1, z2) + map.get(x2, z2)) / 2 + offset(roughness));
        map.set(x1, mz, (map.get(x1, z1) + map.get(x1, z2)) / 2 + offset(roughness));
        map.set(x2, mz, (map.get(x2, z1) + map.get(x2, z2)) / 2 + offset(roughness));

        roughness *= 0.5f;

        divide(map, x1, z1, mx, mz, roughness);
        divide(map, mx, z1, x2, mz, roughness);
        divide(map, x1, mz, mx, z2, roughness);
        divide(map, mx, mz, x2, z2, roughness);
    }

    private float offset(float roughness) {
        return (random.nextFloat() * 2f - 1f) * roughness;
    }
}
