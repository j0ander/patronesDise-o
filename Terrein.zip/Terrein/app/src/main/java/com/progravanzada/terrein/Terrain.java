package com.progravanzada.terrein;

import android.opengl.GLES20;
import java.nio.*;

public class Terrain {

    private final FloatBuffer vertexBuffer;
    private final ShortBuffer indexBuffer;
    private final int indexCount;

    public Terrain(HeightMap map) {

        int size = map.getSize();
        float[][] h = map.getData();

        float[] vertices = new float[size * size * 3];
        short[] indices = new short[(size - 1) * (size - 1) * 6];

        int v = 0;
        for (int z = 0; z < size; z++) {
            for (int x = 0; x < size; x++) {
                vertices[v++] = x * 0.15f;
                vertices[v++] = h[z][x] * 2.5f;
                vertices[v++] = z * 0.15f;
            }
        }

        int i = 0;
        for (int z = 0; z < size - 1; z++) {
            for (int x = 0; x < size - 1; x++) {

                short tl = (short) (z * size + x);
                short tr = (short) (tl + 1);
                short bl = (short) ((z + 1) * size + x);
                short br = (short) (bl + 1);

                indices[i++] = tl;
                indices[i++] = bl;
                indices[i++] = tr;

                indices[i++] = tr;
                indices[i++] = bl;
                indices[i++] = br;
            }
        }

        indexCount = indices.length;

        vertexBuffer = ByteBuffer.allocateDirect(vertices.length * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
                .put(vertices);
        vertexBuffer.position(0);

        indexBuffer = ByteBuffer.allocateDirect(indices.length * 2)
                .order(ByteOrder.nativeOrder())
                .asShortBuffer()
                .put(indices);
        indexBuffer.position(0);
    }

    public void draw(int posHandle) {
        GLES20.glEnableVertexAttribArray(posHandle);
        GLES20.glVertexAttribPointer(posHandle, 3,
                GLES20.GL_FLOAT, false, 0, vertexBuffer);

        GLES20.glDrawElements(GLES20.GL_TRIANGLES,
                indexCount, GLES20.GL_UNSIGNED_SHORT, indexBuffer);

        GLES20.glDisableVertexAttribArray(posHandle);
    }
}
