package com.progravanzada.terrein;


public class HeightMap {

    private final float[][] data;
    private final int size;

    public HeightMap(int size) {
        this.size = size;
        data = new float[size][size];
    }

    public void set(int x, int z, float value) {
        data[z][x] = value;
    }

    public float get(int x, int z) {
        return data[z][x];
    }

    public int getSize() {
        return size;
    }

    public float[][] getData() {
        return data;
    }
}
