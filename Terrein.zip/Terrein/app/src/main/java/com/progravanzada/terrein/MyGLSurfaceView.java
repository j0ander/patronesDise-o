package com.progravanzada.terrein;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class MyGLSurfaceView extends GLSurfaceView {

    private final MyGLRenderer renderer;
    private float previousDistance = 0;

    public MyGLSurfaceView(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        renderer = new MyGLRenderer();
        setRenderer(renderer);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        // ZOOM CON DOS DEDOS (SENCILLO)
        if (event.getPointerCount() == 2) {

            float dx = event.getX(0) - event.getX(1);
            float dy = event.getY(0) - event.getY(1);
            float distance = (float) Math.sqrt(dx * dx + dy * dy);

            if (previousDistance != 0) {
                renderer.zoom((previousDistance - distance) * 0.02f);
            }

            previousDistance = distance;
            return true;
        }

        // Reiniciar cuando se suelta
        if (event.getAction() == MotionEvent.ACTION_UP) {
            previousDistance = 0;
        }

        return true;
    }
}

