package com.progravanzada.terrein;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {
    private TerrainMesh mesh;
    private int meshProgram;

    private Terrain terrain;
    private int program;
    private int aPos;
    private int uMVP;

    private final float[] projection = new float[16];
    private final float[] view = new float[16];
    private final float[] model = new float[16];
    private final float[] temp = new float[16];
    private final float[] mvp = new float[16];

    // ====== CÁMARA ======
    private float angleX = 45f;   // rotación horizontal
    private float angleY = 30f;   // rotación vertical
    private float distance = 12f; // zoom

    // ====== MÉTODOS PARA TOUCH ======
    public void rotate(float dx, float dy) {
        angleX += dx;
        angleY += dy;

        // límite vertical (evita voltear cámara)
        angleY = Math.max(-85f, Math.min(85f, angleY));
    }

    public void zoom(float dz) {
        distance += dz;
        distance = Math.max(4f, Math.min(30f, distance));
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {

        GLES20.glClearColor(
                0.6f, 0.8f, 1.0f, 1.0f   // azul cielo
        );
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        program = ShaderUtils.createProgram(
                TerrainShader.VERTEX,
                TerrainShader.FRAGMENT
        );

        MidpointDisplacement md = new MidpointDisplacement();
        HeightMap map = md.generate(129, 1.2f);
        terrain = new Terrain(map);
        meshProgram = ShaderUtils.createProgram(
                MeshShader.VERTEX,
                MeshShader.FRAGMENT
        );

        terrain = new Terrain(map);
        mesh = new TerrainMesh(map);

    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {

        GLES20.glViewport(0, 0, width, height);
        float ratio = (float) width / height;

        Matrix.frustumM(
                projection, 0,
                -ratio, ratio,
                -1, 1,
                2f, 30f
        );
    }

    @Override
    public void onDrawFrame(GL10 gl) {

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        GLES20.glUseProgram(program);

        aPos = GLES20.glGetAttribLocation(program, "aPos");
        uMVP = GLES20.glGetUniformLocation(program, "uMVP");

        // ====== CÁMARA ORBITAL ======
        float radX = (float) Math.toRadians(angleX);
        float radY = (float) Math.toRadians(angleY);

        float camX = (float) (Math.cos(radY) * Math.sin(radX)) * distance;
        float camY = (float) Math.sin(radY) * distance;
        float camZ = (float) (Math.cos(radY) * Math.cos(radX)) * distance;

        Matrix.setLookAtM(
                view, 0,
                camX, camY, camZ,
                4f, 0f, 4f,   // centro del terreno
                0f, 1f, 0f
        );

        Matrix.setIdentityM(model, 0);

        Matrix.multiplyMM(temp, 0, view, 0, model, 0);
        Matrix.multiplyMM(mvp, 0, projection, 0, temp, 0);

        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0);
        terrain.draw(aPos);

        // ====== DIBUJAR MALLA ======
        GLES20.glUseProgram(meshProgram);

        int aPosMesh = GLES20.glGetAttribLocation(meshProgram, "aPos");
        int uMVPMesh = GLES20.glGetUniformLocation(meshProgram, "uMVP");

        GLES20.glUniformMatrix4fv(uMVPMesh, 1, false, mvp, 0);
        mesh.draw(aPosMesh);

    }
}
