package com.main;

import com.model.Cajero;
import com.model.CajeroAutomatico;

import java.util.Scanner;

public class AppTemplate {
    public static void main(String[] args) {
        Cajero cajero = new Cajero("123321431CA", 789);
        CajeroAutomatico cajeroAutomatico = new CajeroAutomatico("1231412CC", 2540);
        cajero.confirmar(men);
    }
    public static int menu(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Escoja una opcion: 1. Depositar  2.Retirar  3.Consultar Saldo");
        return sc.nextInt();
    }
}
