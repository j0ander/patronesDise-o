package com.model;

public abstract class CuentaBancaria {
    private String cuenta;
    private int saldo;

    public CuentaBancaria(String cuenta, int saldo) {
        this.cuenta = cuenta;
        this.saldo = saldo;
    }

    //SIMILAR PARA TODOS (CLASES) ENTONCES ES PRIVATE
    private void retirar(int valor) {
        if (valor <= this.saldo - 5) {
            this.saldo -= valor;
        } else {
            System.out.printf("Saldo insuficiente, no se puede realizar la transaccion");
        }
    }

    //SIMILAR PARA TODOS (CLASES) ENTONCES ES PRIVATE
    private void depositar(int valor) {
        this.saldo += valor;
    }

    //SIMILAR PARA TODOS (CLASES) ENTONCES ES PRIVATE
    private void consultarSaldo() {
        System.out.println("El saldo actual de la cuenta: " + this.cuenta + "es: " + this.saldo);
    }

    public abstract void confirmar();

    protected void auditoria(){
        System.out.println("se ha almacenado en memoria la transaccion realizada de la cuenta: " + this.cuenta);
    }
    //tipo = tipo de transaccion que se resquiere realizar
    public void procesar(String c, int valor, int tipo){
        confirmar();
        switch (tipo){
            case 1:
                depositar(valor);
                break;
            case 2:
                retirar(valor);
                break;
            case 3:
                consultarSaldo();
                break;
            default:
                System.out.println("Opcion no valida");
        }
        auditoria();
    }

    public int getSaldo() {
        return saldo;
    }

    public String getCuenta() {
        return cuenta;
    }
}
