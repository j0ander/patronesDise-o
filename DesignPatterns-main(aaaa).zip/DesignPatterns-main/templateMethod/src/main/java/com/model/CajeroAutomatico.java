package com.model;

public class CajeroAutomatico extends CuentaBancaria{
    public CajeroAutomatico(String cuenta, int saldo){
        super(cuenta, saldo);

    }
    @Override
    public void confirmar() {
        System.out.println("Que tipo de transaccion va a realizar");
        procesar(super.getCuenta(),valor,tipo);

    }
}
