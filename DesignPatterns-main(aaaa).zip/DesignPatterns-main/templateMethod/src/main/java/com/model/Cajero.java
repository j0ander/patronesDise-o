package com.model;

public class Cajero extends CuentaBancaria{
    private  String name = "ANA";

    public Cajero(String cuenta, int saldo){
        super(cuenta, saldo);

    }
    @Override
    public void confirmar(int tipo,  int valor) {
        System.out.println("Bienvenido al banco, que transaccion va a realizar, mi nombre es: " + this.name);
        procesar(super.getCuenta(),valor,tipo);
    }

    @Override
    public void auditoria(){
        super.auditoria();
        System.out.println("Fue un placer atenderle");
    }
}
