package com.inter;

import com.impl.ProductoDescuento;
import com.impl.ProductoNormal;

public interface Visitor {
    double visit(ProductoNormal productoNormal);
    double visit(ProductoDescuento productoDescuento);
}
