package com.inter;

public interface Visitable {
    double accept(Visitor visitor);
}
