package com.impl;

import com.inter.Visitable;
import com.inter.Visitor;

public class ProductoDescuento implements Visitable {
    private double precio;

//    public ProductoDescuento(double precio){
//        this.precio = precio;
//    }

    @Override
    public double accept(Visitor visitor) {
        return visitor.visit(this);
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}
