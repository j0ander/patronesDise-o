package com.impl;

import com.inter.Visitor;

public class IVA implements Visitor {
    private final double impNormal = 1.12;
    private final double impDescuento = 1.02;


    @Override
    public double visit(ProductoNormal productoNormal) {

        return productoNormal.getPrecio() * impNormal;
    }

    @Override
    public double visit(ProductoDescuento productoDescuento) {

        return productoDescuento.getPrecio() * impDescuento;
    }
}
