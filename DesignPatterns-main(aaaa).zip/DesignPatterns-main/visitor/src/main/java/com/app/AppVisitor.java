package com.app;

import com.impl.IVA;
import com.impl.ProductoDescuento;
import com.impl.ProductoNormal;

public class AppVisitor {

    public static void main(String[] args) {
        ProductoDescuento pd = new ProductoDescuento();
        pd.setPrecio(120);
        ProductoNormal pn = new ProductoNormal();
        pn.setPrecio(120);
        IVA i = new IVA();
        double res1 = pd.accept(i);
        double res2 = pn.accept(i);
        System.out.println(res1);
        System.out.println(res2);
    }
}
