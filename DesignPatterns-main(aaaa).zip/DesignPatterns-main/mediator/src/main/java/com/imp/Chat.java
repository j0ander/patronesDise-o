package com.imp;

import com.inter.Mediator;
import com.model.Usuario;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Chat implements Mediator {
    private List<Usuario> users = new ArrayList<Usuario>();
    private Lock lock = new ReentrantLock(); //VERIFICACION DEL HILO
    @Override
    public void addUser(Usuario user) {
        users.add(user);
    }

    @Override
    public void sendMessage(String mns, Usuario user) {
        lock.lock();
        try {
            for(var u: users){
                if(u != user){
                    u.receive(mns);
                }
            }
        }finally {
            lock.unlock();
        }
    }
}
