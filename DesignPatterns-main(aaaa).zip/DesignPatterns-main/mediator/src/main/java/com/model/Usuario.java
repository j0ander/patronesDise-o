package com.model;

import com.inter.Mediator;

public abstract class Usuario {
    protected Mediator mediator;
    protected  String name;

    public abstract void send(String mns);
    public abstract void receive(String mns);

    public Usuario(Mediator med, String name){
        this.mediator = med;
        this.name = name;
    }
}
