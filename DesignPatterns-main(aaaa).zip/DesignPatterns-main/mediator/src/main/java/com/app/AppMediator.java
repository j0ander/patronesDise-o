package com.app;

import com.imp.Chat;
import com.inter.Mediator;
import com.model.Usuario;

public class AppMediator {
    public static void main(String[] args) {
        Mediator salaChat = new Chat();
        Usuario user1 = new ConcretUsuario(salaChat,"Ana");
        Usuario user2 = new ConcretUsuario(salaChat,"Juan");
        Usuario user3 = new ConcretUsuario(salaChat,"Carlos");
        Usuario user4 = new ConcretUsuario(salaChat,"Mateo");
        salaChat.addUser(user1);
        salaChat.addUser(user2);
        salaChat.addUser(user3);
        salaChat.addUser(user4);
        user1.send("adlkjdah");
    }
}
