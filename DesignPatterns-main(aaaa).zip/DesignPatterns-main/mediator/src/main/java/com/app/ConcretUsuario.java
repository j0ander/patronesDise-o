package com.app;

import com.inter.Mediator;
import com.model.Usuario;

public class ConcretUsuario extends Usuario {
    public ConcretUsuario(Mediator med, String name){
        super(med, name);
    }
    @Override
    public void send(String mns) {
        mediator.sendMessage(mns, this);
    }

    @Override
    public void receive(String mns) {
        System.out.println(name + " esta reciviendo mensaje: " + mns);

    }
}
