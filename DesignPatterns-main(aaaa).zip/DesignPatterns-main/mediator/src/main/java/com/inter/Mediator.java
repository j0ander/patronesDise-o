package com.inter;

import com.model.Usuario;

public interface Mediator {
    void sendMessage(String mns, Usuario user);
    void addUser(Usuario user);
}
