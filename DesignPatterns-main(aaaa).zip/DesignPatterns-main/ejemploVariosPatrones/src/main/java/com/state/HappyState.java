package com.state;

import com.model.Tamagotchi;
import com.state.anotaciones.TamagotchiState;
import com.strategy.IComidaStrategy;

@TamagotchiState("HAPPY")
public class HappyState implements IState {


    @Override
    public void onActividad(Tamagotchi t) { //actividad == jugar
        System.out.println("Estoy feliz, vamos a jugar");
        t.setState("SLEEPING");
    }

    @Override
    public void onComer(Tamagotchi t, IComidaStrategy s) {
        System.out.println("No tengo hambre, estoy muy feliz ");
    }

    @Override
    public void onDormir(Tamagotchi t) {
        System.out.println("No quiero dormir, estoy muy feliz");
    }

    @Override
    public void onDescansar(Tamagotchi t) {
        System.out.println("No quiero descansar, estoy muy feliz");
    }
}
