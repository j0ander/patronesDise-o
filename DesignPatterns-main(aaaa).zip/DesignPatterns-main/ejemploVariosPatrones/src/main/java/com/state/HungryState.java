package com.state;

import com.model.Tamagotchi;
import com.state.anotaciones.TamagotchiState;
import com.strategy.IComidaStrategy;


@TamagotchiState("HUNGRY")
public class HungryState implements IState {

    @Override
    public void onActividad(Tamagotchi t) { //actividad == jugar
        System.out.println("Estoy hambriento, no quiero jugar");
    }

    @Override
    public void onComer(Tamagotchi t, IComidaStrategy s) {
        int value = s.feed();
        t.incHunger(value);
        System.out.println("Comer, yuppii, ahora me siento mejor");
        t.setState("HAPPY");
    }

    @Override
    public void onDormir(Tamagotchi t) {
        System.out.println("No puedo dormir con hambre");

    }

    @Override
    public void onDescansar(Tamagotchi t) {
        System.out.println("No puedo descansar con hambre");

    }
}
