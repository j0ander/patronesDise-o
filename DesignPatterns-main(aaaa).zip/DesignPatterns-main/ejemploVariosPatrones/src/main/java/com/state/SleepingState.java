package com.state;

import com.model.Tamagotchi;
import com.state.anotaciones.TamagotchiState;
import com.strategy.IComidaStrategy;

@TamagotchiState("SLEEPING")
public class SleepingState implements IState{

    @Override
    public void onActividad(Tamagotchi t) { //actividad == jugar
        System.out.println("Zzzzz El tamagotchi esta dormido");
    }

    @Override
    public void onComer(Tamagotchi t, IComidaStrategy s) {
        System.out.println("Zzzzzz no comer");
    }

    @Override
    public void onDormir(Tamagotchi t) {
        System.out.println("Ya esta dormido.....");
    }

    @Override
    public void onDescansar(Tamagotchi t) {
        System.out.println("Ya se esta despertando");
        t.setState("HUNGRY");
    }
}
