package com.app;

import com.model.Tamagotchi;
import com.observer.ConsolaObserver;
import com.strategy.ComidaRapidaStrategy;
import com.strategy.ComidaSaludableStrategy;

import java.util.Scanner;

public class AppTamagotchi {
    public static void main(String[] args) {
        Tamagotchi t1 = new Tamagotchi();
        t1.addObserver(new ConsolaObserver());
        System.out.println("Bienvenido al juego del Tamagotchi............");
        menu(t1);


    }

    public static void menu(Tamagotchi t){
        Scanner sc = new Scanner(System.in);
        boolean ejecutar = true;
        System.out.println("1.Jugar  2.Alimentar CR  3.Alimentar CS  4.Dormir   5.Descansar   6.Salir");
        while(ejecutar){
            System.out.println("Escoja una opcion");
            int op = sc.nextInt();
            switch(op){
                case 1 -> t.act();
                case 2 -> t.feed(new ComidaRapidaStrategy());
                case 3 -> t.feed(new ComidaSaludableStrategy());
                case 4 -> t.sleep();
                case 5 -> t.passTime();
                case 6 -> {ejecutar = false;
                    System.out.println("hasta pronto");}
                default -> System.out.println("Opcion invalida");
            }
        }
    }
}
