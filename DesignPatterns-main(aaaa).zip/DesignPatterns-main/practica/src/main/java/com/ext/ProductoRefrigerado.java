package com.ext;

import com.model.Producto;

public class ProductoRefrigerado extends Producto {
    private int codigo;
    private int temperatura;
    public ProductoRefrigerado(int n,String fc, String fe, String pais, int codigo, int temperatura ) {
        super(n,fc,fe,pais);
        this.codigo = codigo;
        this.temperatura = temperatura;
    }
}
