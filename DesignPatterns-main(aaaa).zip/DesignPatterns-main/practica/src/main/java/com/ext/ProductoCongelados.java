package com.ext;

import com.model.Producto;

public abstract class ProductoCongelados extends Producto {
    public ProductoCongelados(int n, String fc, String fe, String pais) {
        super(n,fc,fe,pais);
    }
}
