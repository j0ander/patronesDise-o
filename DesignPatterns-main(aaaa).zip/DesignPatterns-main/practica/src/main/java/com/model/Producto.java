package com.model;

public abstract class Producto {

    private int n;
    protected String fechaCaducidad;
    protected String numeroLote;
    protected String paisOrigen;

    public Producto(int n, String fechaCaducidad, String numeroLote, String paisOrigen) {
        this.fechaCaducidad = fechaCaducidad;
        this.numeroLote = numeroLote;
        this.paisOrigen = paisOrigen;
    }

    public Producto() {

    }


    public void mostrarDatosBase() {
        System.out.println("  Fecha caducidad: " + fechaCaducidad);
        System.out.println("  N° lote: " + numeroLote);
        System.out.println("  País origen: " + paisOrigen);
    }
}
