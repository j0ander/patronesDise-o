package com;

import com.base.NotificacionBase;
import com.inter.Notificacion;
import com.model.DecoratorLoader;
import com.model.NotificacionCorreo;
import com.model.NotificacionPush;
import com.model.NotificacionSMS;

import java.lang.reflect.Constructor;
import java.util.HashSet;
import java.util.Set;

public class AppDecorator {
    static String decoradores[] = {"NotificacionSMS", "NotificacionPush", "NotificacionCorreo", "NotidicacionBase"};
    public static void main(String[] args) throws Exception {


//        Notificacion not = new NotificacionBase();
//        for(String clase: decoradores){
//            Class<?> clazz = Class.forName(clase);
//            Constructor<?> constructor = clazz.getConstructor(Notificacion.class);
//            not = (Notificacion) constructor.newInstance(not);
//
//        }

//        Notificacion notificacion = new NotificacionSMS(
//                new NotificacionPush(
//                        new NotificacionCorreo(
//                                new NotificacionBase()))); //le pasamos todas aquellas funcionalidades que nosotros necesitemos

//        Set<Class<?>> classes = new HashSet<Class<?>>();

//        not.enviar("holalallsdkaoijdsoijas Enviada por todos los componentes adicionales");
          DecoratorLoader decoratorLoader = new DecoratorLoader();
          decoratorLoader.init("com.model");
          Notificacion n1 = decoratorLoader.createFactory("sms");
    }
}
