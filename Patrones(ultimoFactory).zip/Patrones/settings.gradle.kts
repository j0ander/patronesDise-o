rootProject.name = "Patrones"
include("singleton")
include("factory")
include("ejercicioFactoryBasico")

